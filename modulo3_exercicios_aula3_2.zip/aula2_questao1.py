# Questão 1
juliana = int(input("Digite a idade de Juliana: "))
cris = int(input("Digite a idade de Cris: "))

pode_entrar = juliana > 17 and cris > 17
print(pode_entrar)
