# Questão 2
juliana = int(input("Digite a idade de Juliana: "))
cris = int(input("Digite a idade de Cris: "))

pode_entrar = juliana > 17 or cris > 17
print(pode_entrar)
