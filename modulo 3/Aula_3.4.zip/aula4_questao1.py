# Aula 3.4 - Questão 1
num1 = int(input("Digite o primeiro número: "))
num2 = int(input("Digite o segundo número: "))
soma = num1 + num2
if soma % 2 == 0:
    print("A soma é par.")
else:
    print("A soma é ímpar.")