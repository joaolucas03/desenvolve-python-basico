# Aula 3.4 - Questão 4
distancia = float(input("Digite a distância em km: "))
peso = float(input("Digite o peso do pacote em kg: "))
if distancia <= 100:
    valor = peso * 1.0
elif distancia <= 300:
    valor = peso * 1.5
else:
    valor = peso * 2.0
if peso > 10:
    valor += 10
print(f"Valor do frete: R${valor:.2f}")